package com.edu.oper;

import java.util.Scanner;

public class StudentMarks {

	public static void main(String[] args) {
		int marks;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Marks");
		
		marks=sc.nextInt();
		if(marks>=90 && marks<=100) {
			System.out.println("Greade A");
		}else if(marks>=70 && marks<=89) {
			System.out.println("Greade B");
		}else if(marks>=50 && marks<=69) {
			System.out.println("Greade c");
		}else if(marks>=30 && marks<=49) {
			System.out.println("Greade D");
		}else if(marks>=0 && marks<=29) {
			System.out.println("Fail");
		}
		
		

	}

}
