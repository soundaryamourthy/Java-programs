package soundarya;

public class Circle {

	public static void main(String[] args) {
		double pi = 3.14;
		int r = 5;
		double area = pi *(r*r);
		System.out.println("The area of circle is:" +area);

	}

}
