package soundarya;

public class Multiplication {

	public static void main(String[] args) {
		int num1, num2, ans;
		num1=12;
		num2=2;
		
		ans=num1*num2;
		System.out.println("the answer of  " +num1+  " and " +num2+  " is "+ans);


	}

}
