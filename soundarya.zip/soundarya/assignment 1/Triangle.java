package soundarya;

public class Triangle {

	public static void main(String[] args) {
		int b , h;
		float area;
		b = 10;
		h = 2;
		area = (b*h)/2;
		System.out.println("The area of triangle is:" +area);

	}

}
