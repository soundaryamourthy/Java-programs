package soundarya;

public class Subtraction {

	public static void main(String[] args) {
		int num1, num2, ans;
		num1 = 58;
		num2 = 23;
		ans = num1 - num2;
		System.out.println("The answer of  " +num1+ " and "  +num2+ " is "  +ans);


	}

}
