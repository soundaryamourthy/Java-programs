package soundarya;

public class Rectangle {

	public static void main(String[] args) {
		int l , b;
		float area;
		l = 10;
		b = 2;
		area = l * b;
		System.out.println("The area of rectangle is:" +area);
		

	}

}
