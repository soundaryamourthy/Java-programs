package soundarya;

public class VariablesMain {

	public static void main(String[] args) {
	      int firstnum=10;
	      System.out.println("The first number is"+firstnum);
		

	}

}
