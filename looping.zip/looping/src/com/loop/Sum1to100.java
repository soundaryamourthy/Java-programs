package com.loop;

public class Sum1to100 {

	public static void main(String[] args) {
		int i,s=0;
		i=1;
		while(i<=100) {
			
			s=s+i;
			i=i+1;
		}
		System.out.println("Total of 1 to 100 natural numbers = " +s);

	}

}
