package com.loop;

public class DoWhile {

	public static void main(String[] args) {
		int num = 6;
		System.out.println("Factors of the number is :");
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				System.out.println(i+ "");


	}

		}
	}
}
