package com.loop;

public class Number1to100 {

	public static void main(String[] args) {
		int i;
		for(i=1;i<=100;i++) {
			System.out.println(i);
		}

	}

}
