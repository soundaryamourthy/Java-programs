package com.loop;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		int n;
		double fact=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the factorial number :");
		n=sc.nextInt();
		for(int i=n;i>1;i--) {
			fact=fact*i;
		}
		System.out.println("Factorial of "+n+" is  " +fact);

	}

}
