package com.loop;
import java.util.Scanner;

public class PrimeCheck {

	public static void main(String[] args) {
		int num,fc=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number to check prime");
		num = sc.nextInt();
		for(int i=1;i<num;i++) {
			if(num%i==0) {
				fc++;
			}
		}
		
         if(fc==2) {
        	 System.out.println(num+" is prime");
         }
         else
         {
        	 System.out.println(num+ " is not a prime");
         }
        	 
	}

}
