package com.loop;

public class SumOfFactors {

	public static void main(String[] args) {
		int i, fact=1;
		for(i=1;i<4;i++)
		{
			fact=fact*i;
		}
		System.out.println(fact);
	}


	}


