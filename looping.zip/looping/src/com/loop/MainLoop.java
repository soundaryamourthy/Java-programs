package com.loop;

public class MainLoop {

	public static void main(String[] args) {
		int i;
		i=1;
		
		while(i<=5) {
			System.out.println("soundarya");
			i=i+1;
		}

	}

}
