package com.loop;

public class EvenNumUsingFor {

	public static void main(String[] args) {
		int i;
		for(i=2;i<=100;i=i+2) {
			System.out.println(i);

		}
	}
}


