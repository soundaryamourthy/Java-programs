package com.loop;

public class OddNumbers {

	public static void main(String[] args) {
		int i;
		i=2;
		
		while(i<=100) {
			System.out.println(i);
			i=i+2;
		}

	}

}
