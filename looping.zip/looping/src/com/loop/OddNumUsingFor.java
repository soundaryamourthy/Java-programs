package com.loop;

public class OddNumUsingFor {

	public static void main(String[] args) {
		int i;
		for(i=1;i<=100;i=i+2) {
			System.out.println(i);

	}

}
}