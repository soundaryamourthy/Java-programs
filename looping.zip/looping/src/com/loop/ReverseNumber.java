package com.loop;
import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		int num,digit;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		num=sc.nextInt();
			
			while(num!=0) {
				digit=num%10;
			    System.out.print(digit);
				num=num/10;
			}
		
			 

	}

}
