package Experiment;

public class StudentAge {
      public static void StudentAge() {
		        int age = 0;  
		        age = age+20;
		        System.out.println("Student age is:" +age); 
		        
		    } 
		   
		     
		 public static void main(String[] args) { 
		        StudentAge temp = new StudentAge();  
		        temp.StudentAge();
		        
	}

}
