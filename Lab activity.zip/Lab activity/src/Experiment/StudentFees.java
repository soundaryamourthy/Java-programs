package Experiment;

class Student {  
	    
	public static double fees;     
	public static String name = "kavi";   
}
	 

public class StudentFees {

	public static void main(String[] args) {
		Student.fees = 80000;        
		System.out.println(Student.name + "'s annual fees : " 
		  + Student.fees);   
		
	}

}
