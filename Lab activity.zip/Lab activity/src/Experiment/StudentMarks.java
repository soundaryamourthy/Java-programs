package Experiment;

class SubjectMarks {  
    
    int ScienceMarks;  
    int MathsMarks;  
    int GKMarks;  
}  
 
public class StudentMarks {

	public static void main(String[] args) {
 
        SubjectMarks Subj1 = new SubjectMarks();
        Subj1.ScienceMarks = 78;  
        Subj1.MathsMarks = 56;  
        Subj1.GKMarks = 90;  
    
        SubjectMarks Subj2 = new SubjectMarks();  
        Subj2.ScienceMarks = 80;  
        Subj2.MathsMarks = 70;  
        Subj2.GKMarks = 95;  
    
        System.out.println("Marks for first object:");  
        System.out.println(Subj1.ScienceMarks);  
        System.out.println(Subj1.MathsMarks);  
        System.out.println(Subj1.GKMarks);  
     
        System.out.println("Marks for second object:");  
        System.out.println(Subj2.ScienceMarks);  
        System.out.println(Subj2.MathsMarks);  
        System.out.println(Subj2.GKMarks);  
	}

}
