package Experiment;

public class BooleanMain {

	public static void main(String[] args) {
		  boolean IoT = true; 
		     System.out.println(IoT); 
		       
		     byte range; 
		     range = 127; 
		     System.out.println(range); 
		      
		     short range1; 
		     range1 = -127; 
		     System.out.println(range1); 
		      
		     int range2 = 300000000; 
		     System.out.println(range2); 
		       
		     long range3 = 30000000000L; 
		     System.out.println(range3); 
		      
		     double number = 99.9; 
		     System.out.println(number); 
		       
		     float number1 = 99.9f; 
		     System.out.println(number1); 
		       
		     char letter = '\u0041'; 
		     System.out.println(letter); 
		     char letter2 = 65;   
		     System.out.println(letter2); 
		 
		     char letter3 = 'A'; 
		     System.out.println(letter3); 
	}

}
