package com.operator;

public class Comparisionop {

	public static void main(String[] args) {
		int i=8,j=2;
		boolean b;
		
		b=i>j;
		System.out.println("b="+b);
		
		b=i<j;
		System.out.println(b);
		
		b=(i==j);
		System.out.println("both are equal or not " +b);

	}

}
