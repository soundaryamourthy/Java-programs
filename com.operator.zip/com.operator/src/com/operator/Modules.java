package com.operator;

public class Modules {

	public static void main(String[] args) {
		int i=5,j=5,q,r;
		r=i%j;
		System.out.println("r="+r);
		q=i/j;
		
		System.out.println("q="+q);

	}

}
