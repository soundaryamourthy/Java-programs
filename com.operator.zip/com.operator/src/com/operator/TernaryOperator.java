package com.operator;

import java.util.Scanner;

public class TernaryOperator {

	public static void main(String[] args) {
		int fnum,snum,lar;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 2 numbers");
		fnum=sc.nextInt();
		snum=sc.nextInt();
		
		lar = (fnum>snum)?fnum:snum;
		
		System.out.println("The largest of "+fnum+" and "+snum+" is "+lar);
		
	}

}
