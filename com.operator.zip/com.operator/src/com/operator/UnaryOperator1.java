package com.operator;

public class UnaryOperator1 {

	public static void main(String[] args) {
		int i,j,k;
		i=3;
		j=6;k=i++ + ++j;
		
		System.out.println("k="+k);
		System.out.println("i="+i);
		System.out.println("j="+j);
		

	}

}
