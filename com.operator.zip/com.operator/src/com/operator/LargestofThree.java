package com.operator;

import java.util.Scanner;

public class LargestofThree {

	public static void main(String[] args) {
		int fnum,snum,tnum,largest;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 numbers");
		fnum=sc.nextInt();
		snum=sc.nextInt();
		tnum=sc.nextInt();
		
		largest = (fnum>snum && fnum>tnum)?fnum:(snum>fnum && snum>tnum)?snum:tnum;
		
		System.out.println("The largest of "+fnum+" and "+snum+" and "+tnum+ " is "+largest);

	}

}
