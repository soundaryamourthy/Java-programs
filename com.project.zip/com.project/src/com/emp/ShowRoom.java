package com.emp;

import java.util.Scanner;

public class ShowRoom {
     String name;
     long mobno;
     double cost;
     double dis;
     double amount;
   
  void input() {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter customer name:");
	  name=sc.next();
	  System.out.println("Enter mobile number:");
	  mobno=sc.nextInt();
	  System.out.println("Enter cost:");
	  cost=sc.nextInt();
  }
  void calculate() {
	  if(cost<=10000) {
		  dis= cost*5/100;
		  amount=cost-dis;
	  }else if(cost>=10000&&cost<=20000) {
		  dis=cost*10/100;
		  amount=cost-dis;
	  }else if(cost>=20000&&cost<=35000) {
		  dis=cost*15/100;
		  amount=cost-dis;
	  }else if(cost>=35000) {
		  dis=cost*20/100;
		  amount=cost-dis;
	  }
  }
  void display() {
		System.out.println("Name ="+name);
		System.out.println("Mobile num="+mobno);
		System.out.println("Cost="+cost);
  }  

	public static void main(String[] args) {
		
          ShowRoom ob=new ShowRoom();
          ob.input();
          ob.calculate();
          ob.display();
	}
}



