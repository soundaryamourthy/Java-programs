package com.emp;

import java.util.Scanner;

class EduEmployee{
	int eid;
	String ename;
	static String cname="Info Tech";
	
	void inputEmp() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter eid");
		eid=sc.nextInt();
		System.out.println("Enter employee Name");
		ename=sc.next();
	}
	void display() {
		System.out.println("Eid ="+eid);
		System.out.println("Ename="+ename);
		System.out.println("Company Name="+cname);
	}
	
}

public class EmployeeDetails {

	public static void main(String[] args) {
		
		EduEmployee eob[]=new EduEmployee[5];  //array of objects      //int ar[]=new int[10];
		for(int i=0;i<eob.length;i++) {
			 eob[i]=new EduEmployee();
			 eob[i].inputEmp();
		}
		System.out.println("Employee Records are");
		for(int i=0;i<eob.length;i++) {
			eob[i].display();
		}
		

	}

}
