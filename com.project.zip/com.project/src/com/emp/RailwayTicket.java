package com.emp;

import java.util.Scanner;

public class RailwayTicket {
	String name;
	String coach;
	long mobno;
	int amt;
	int totalamt;
	
	void accept() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name:");
		name=sc.next();
		System.out.println("Enter the coach:");
		coach=sc.next();
		System.out.println("Enter the mobile num:");
		mobno=sc.nextInt();
		System.out.println("Enter the amount:");
		amt=sc.nextInt();
	}
	
	void update() {
		if(coach.equals("First_AC")) {
			totalamt=amt+700;
		}else if(coach.equals("Second_AC")) {
			totalamt=amt+500;
		}else if(coach.equals("Third_AC")) {
			totalamt=amt+250;
		}else if(coach.equals("sleeper")) {
		  System.out.println("none");
		}
	}
    void display() {
    	System.out.println("Name ="+name);
    	System.out.println("coach ="+coach);
    	System.out.println("mobile num ="+mobno);
    	System.out.println("totalamt ="+totalamt);
    }
	public static void main(String[] args) {
		RailwayTicket ticket=new RailwayTicket();
		ticket.accept();
		ticket.update();
		ticket.display();
	}

}
