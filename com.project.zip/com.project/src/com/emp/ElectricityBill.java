package com.emp;
import java.util.Scanner;
public class ElectricityBill {
	String n;
	int units;
	double bill;

void accept() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter name of the customer");
	n=sc.next();
	System.out.println("Enter number of unit consumed");
	units=sc.nextInt();
}
void calculate() {
	if(units<=100) {
		bill = 2*units;
	}else if(units<=200) {
		bill = 3*units;
	}else if(units>300) {
		bill = 5*units;
	}
}
void display() {
	System.out.println("Name ="+n);
	System.out.println("units ="+units);
	System.out.println("bill ="+bill);
}
	public static void main(String[] args) {
		ElectricityBill eb=new ElectricityBill();
		eb.accept();
		eb.calculate();
		eb.display();

	}

}
