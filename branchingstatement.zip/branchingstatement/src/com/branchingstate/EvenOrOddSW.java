package com.branchingstate;
import java.util.Scanner;
public class EvenOrOddSW {

	public static void main(String[] args) {
				int num;
				Scanner sc = new Scanner(System.in);
		        

			    System.out.println("Enter integer number: ");
			    num = sc.nextInt();

			    switch (num % 2) {
			    case 0:
			      System.out.println(num+ "is Even number");
			      break;
			    case 1:
			    	System.out.println(num+ "is Odd number");
			    	
			    }  	
			    	
			}


	}


