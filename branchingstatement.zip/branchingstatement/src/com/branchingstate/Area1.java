package com.branchingstate;
import java.util.Scanner;

public class Area1 {
	int choice;
	float length,breadth,radius,base,area,height,pi=3.14159f;
	Scanner sc= new Scanner(System.in);

	public void AreaSquare() {
     System.out.println("Enter the values of the square");
     length = sc.nextInt();
     area = length*length;
     System.out.println("Area of square:"+area);
	}
        
    public void AreaRectagle() { 
	System.out.println("Enter the values of the rectangle");
     length = sc.nextInt();
     breadth = sc.nextInt();
     area = length*breadth;
     System.out.println("Area of rectangle:"+area);
    }
    
     public void AreaTriangle() {   
     System.out.println("Enter the values of the triangle");
     base = sc.nextInt();
     height = sc.nextInt();
     area = 1/2*base*height;
     System.out.println("Area of triangle:"+area);
     }
        
     public void AreaCircle() {
     System.out.println("Enter the values of the circle");
     radius = sc.nextInt();
     area = 3.14159f*radius*radius;
     System.out.println("radius of circle:"+area);
     }
        
     public class AreaUsesFunction {    

	public static void main(String[] args) {
		int choice;
		
		Area1 aob = new Area1();
		Scanner sc = new Scanner(System.in);
		System.out.println("*******Menu*********");
		System.out.println("1.Area of Square");
		System.out.println("2.Area of Recatange");
		System.out.println("3.Area of Trinangle");
		System.out.println("4.Area of Circle");
		System.out.println("Enter your choice");
		 choice = sc.nextInt();
		 
		 switch(choice) {
			 case 1:aob.AreaSquare();
			 break;
			 case 2:aob.AreaSquare();
			 break;
			 case 3:aob.AreaSquare();
			 break;
			 case 4:aob.AreaSquare();
			 break;
			 default : System.out.println("Invalid");
		 }	
		
	}
		
	}

}
