package com.branchingstate;
import java.util.Scanner;

public class AreaMain {

	public static void main(String[] args) {
		int choice;
		float area,length,breadth,base,height,radius;
		Scanner sc = new Scanner(System.in);
		System.out.println("*******Menu*********");
		System.out.println("1.Area of Square");
		System.out.println("2.Area of Recatange");
		System.out.println("3.Area of Trinangle");
		System.out.println("4.Area of Circle");
		System.out.println("Enter your choice");
		 choice = sc.nextInt();
	
	     switch(choice) {
	     case 1:System.out.println("Enter the values of the square");
	     length = sc.nextInt();
	     area = length*length;
	     System.out.println("Area of square:"+area);
            break;
            
	     case 2:System.out.println("Enter the values of the rectangle");
	     length = sc.nextInt();
	     breadth = sc.nextInt();
	     area = length*breadth;
	     System.out.println("Area of rectangle:"+area);
            break;
            
	     case 3:System.out.println("Enter the values of the triangle");
	     base = sc.nextInt();
	     height = sc.nextInt();
	     area = 1/2*base*height;
	     System.out.println("Area of triangle:"+area);
            break;
            
	     case 4:System.out.println("Enter the values of the circle");
	     radius = sc.nextInt();
	     area = 3.14159f*radius*radius;
	     System.out.println("radius of circle:"+area);
            break;
            
            default:System.out.println("Invalid");
	     }
	}
	
}
