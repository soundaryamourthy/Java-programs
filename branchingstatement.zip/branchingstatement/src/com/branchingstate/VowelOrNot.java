package com.branchingstate;
import java.util.Scanner;

public class VowelOrNot {

	public static void main(String[] args) {
		char ch;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the character :");
		ch=sc.next().charAt(0);
		
		switch(ch) {
		case 'A' :System.out.println(ch+ "  IS AN VOWEL");
		break;
		case 'a' :System.out.println(ch+ "  is a vowel");
		break;
		case 'E' :System.out.println(ch+ "  IS AN VOWEL");
		break;
		case 'e' :System.out.println(ch+ "  is a vowel");
		break;
		case 'I' :System.out.println(ch+ "  IS AN VOWEL");
		break;
		case 'i' :System.out.println(ch+ "  is a vowel");
		break;
		case 'O' :System.out.println(ch+ "  IS AN VOWEL");
		break;
		case 'o' :System.out.println(ch+ "  is a vowel");
		break;
		case 'U' :System.out.println(ch+ "  IS AN VOWEL");
		break;
		case 'u' :System.out.println(ch+ "  is a vowel");
		break;
		default : System.out.println("it is not a vowel");
		}

	}

}
